# Word2Quiz
Create quizzes in Canvas from a Word docx file with defined paragraph and 
text formatting (H1, H2, numbered lists for the question,
alphabetic lists for the answers) using
[Canvasapi](https://canvasapi.readthedocs.io/en/stable/getting-started.html) with the
CanvasRobot library.

A library to use in a webapp, command-line tool or gui program. 
As an example a simple standalone command-line tool is provided.


