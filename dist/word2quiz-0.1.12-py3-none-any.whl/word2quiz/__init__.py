""" init """
__version__ = '0.1.11'
from .main import parse
from .main import parse_document_d2p
from .main import word2quiz
from .main import get_document_html
from .main import normalize_size
from .main import CanvasRobot