# word2quiz
Create quizzes in Canvas from simple Word docx files uaing Canvasapi.
A library to use in webapp, commandline or gui program. I will add the canvasapi part and make 
it into a standalone tool


