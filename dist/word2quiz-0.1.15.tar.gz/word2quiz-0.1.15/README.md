# Word2Quiz
Create quizzes in Canvas from simple Word docx files using
[Canvasapi](https://canvasapi.readthedocs.io/en/stable/getting-started.html) with the
CanvasRobot library.
A library to use in a webapp, commandline tool or gui program. 
As an example a simple standalone commandline tool will be provided.


